/**
 * FoodLabelReader.com — Embeddable Additive Checker Widget
 * v1.0.0
 *
 * Usage:
 *   <div id="flr-additive-checker"></div>
 *   <script src="https://foodlabelreader.com/widgets/additive-checker.js"></script>
 *
 * Options (via data attributes on the container):
 *   data-theme="dark"   — force dark theme
 *   data-width="400"    — max-width in px (default 420)
 */
(function () {
  'use strict';

  /* ── Additive Database (101 entries, compact) ── */
  var D=[
{c:"E102",n:"Tartrazine",a:"Yellow 5, FD&C Yellow 5",t:"Artificial Colour",h:"high",p:"caution",d:"Synthetic azo dye linked to hyperactivity in children in the 2007 Southampton/Lancet study.",diet:{h:"y",k:"y",v:"y",vn:"y"},al:["az"]},
{c:"E104",n:"Quinoline Yellow",a:"Yellow 13, D&C Yellow 11",t:"Artificial Colour",h:"high",p:"caution",d:"Southampton Six dye requiring EU warning label; banned in the US, Australia, Japan, and Norway.",diet:{h:"y",k:"y",v:"y",vn:"y"},al:[]},
{c:"E110",n:"Sunset Yellow",a:"Yellow 6, FD&C Yellow 6",t:"Artificial Colour",h:"high",p:"caution",d:"Azo dye in the Southampton Six group tested in the landmark 2007 Lancet study on child hyperactivity.",diet:{h:"y",k:"y",v:"y",vn:"y"},al:["az"]},
{c:"E120",n:"Carmine",a:"Cochineal, Natural Red 4, CI 75470",t:"Natural Colour",h:"none",p:"generally-safe",d:"Natural red pigment extracted from dried cochineal insects; rare allergic reactions documented.",diet:{h:"d",k:"n",v:"n",vn:"n"},al:[]},
{c:"E122",n:"Carmoisine",a:"Azorubine, Acid Red 14",t:"Artificial Colour",h:"high",p:"caution",d:"One of the Southampton Six dyes; EU requires warning label, not approved in the US.",diet:{h:"y",k:"y",v:"y",vn:"y"},al:["az"]},
{c:"E124",n:"Ponceau 4R",a:"Brilliant Scarlet, Cochineal Red A",t:"Artificial Colour",h:"high",p:"caution",d:"Azo dye in the Southampton Six group; banned in the US and Norway.",diet:{h:"y",k:"y",v:"y",vn:"y"},al:["az"]},
{c:"E127",n:"Erythrosine",a:"Red 3, FD&C Red 3",t:"Artificial Colour",h:"low",p:"caution",d:"Iodine-containing xanthene dye; FDA revoked food authorisation in 2024 (effective 2027).",diet:{h:"y",k:"y",v:"y",vn:"y"},al:[]},
{c:"E129",n:"Allura Red",a:"Red 40, FD&C Red 40",t:"Artificial Colour",h:"high",p:"caution",d:"The most widely used red food dye globally; part of the Southampton Six.",diet:{h:"y",k:"y",v:"y",vn:"y"},al:["az"]},
{c:"E131",n:"Patent Blue V",a:"Acid Blue 3, CI 42051",t:"Artificial Colour",h:"none",p:"generally-safe",d:"Synthetic triarylmethane dye used primarily in confectionery and beverages.",diet:{h:"y",k:"y",v:"y",vn:"y"},al:[]},
{c:"E132",n:"Indigo Carmine",a:"Indigotine, Blue 2, FD&C Blue 2",t:"Artificial Colour",h:"none",p:"generally-safe",d:"Synthetic indigo dye, the oldest known synthetic food colour; no behavioural concerns.",diet:{h:"y",k:"y",v:"y",vn:"y"},al:[]},
{c:"E133",n:"Brilliant Blue",a:"Blue 1, FD&C Blue 1",t:"Artificial Colour",h:"moderate",p:"caution",d:"Triphenylmethane dye with some case reports of behavioural sensitivity in susceptible children.",diet:{h:"y",k:"y",v:"y",vn:"y"},al:[]},
{c:"E142",n:"Green S",a:"Food Green S, Acid Brilliant Green BS",t:"Artificial Colour",h:"low",p:"caution",d:"Synthetic triarylmethane dye; banned in the US, Canada, Japan, and Norway.",diet:{h:"y",k:"y",v:"y",vn:"y"},al:[]},
{c:"E150a",n:"Plain Caramel",a:"Caramel Colour I",t:"Natural Colour",h:"none",p:"safe",d:"Made by heating sugar without ammonia or sulphite catalysts; considered very safe.",diet:{h:"y",k:"y",v:"y",vn:"y"},al:[]},
{c:"E150d",n:"Sulphite Ammonia Caramel",a:"Caramel Colour IV",t:"Colour",h:"low",p:"caution",d:"Most commonly used caramel colour (in cola drinks); may produce 4-MEI during manufacturing.",diet:{h:"y",k:"y",v:"y",vn:"y"},al:[]},
{c:"E151",n:"Brilliant Black BN",a:"Black PN, CI 28440",t:"Artificial Colour",h:"low",p:"caution",d:"Synthetic azo dye producing a black or dark brown colour; banned in the US and Canada.",diet:{h:"y",k:"y",v:"y",vn:"y"},al:["az"]},
{c:"E155",n:"Brown HT",a:"Chocolate Brown HT, CI 20285",t:"Artificial Colour",h:"low",p:"caution",d:"Synthetic azo dye banned in many countries including the US and several EU nations.",diet:{h:"y",k:"y",v:"y",vn:"y"},al:["az"]},
{c:"E160a",n:"Beta-Carotene",a:"Beta-carotene, Provitamin A",t:"Natural Colour",h:"none",p:"safe",d:"Natural orange-red pigment found in carrots and leafy greens; converted to vitamin A as needed.",diet:{h:"y",k:"y",v:"y",vn:"y"},al:[]},
{c:"E160b",n:"Annatto",a:"Bixin, Norbixin, CI 75120",t:"Natural Colour",h:"moderate",p:"generally-safe",d:"Natural orange-yellow pigment implicated in behavioural reactions in sensitive children.",diet:{h:"y",k:"y",v:"y",vn:"y"},al:[]},
{c:"E160c",n:"Paprika Extract",a:"Capsanthin, Capsorubin",t:"Natural Colour",h:"none",p:"safe",d:"Natural red-orange pigment extracted from paprika peppers; no safety concerns.",diet:{h:"y",k:"y",v:"y",vn:"y"},al:[]},
{c:"E162",n:"Beetroot Red",a:"Betanin, Beet Red",t:"Natural Colour",h:"none",p:"safe",d:"Natural red pigment from beetroot with an excellent safety profile.",diet:{h:"y",k:"y",v:"y",vn:"y"},al:[]},
{c:"E163",n:"Anthocyanins",a:"Grape skin extract",t:"Natural Colour",h:"none",p:"safe",d:"Natural pigments responsible for red, purple, and blue colours in berries and grapes.",diet:{h:"y",k:"y",v:"y",vn:"y"},al:[]},
{c:"E171",n:"Titanium Dioxide",a:"TiO2, CI 77891",t:"Colour / Whitener",h:"low",p:"avoid",d:"Banned in the EU since 2022 due to genotoxicity concerns from nanoparticles.",diet:{h:"y",k:"y",v:"y",vn:"y"},al:[]},
{c:"E200",n:"Sorbic Acid",a:"2,4-hexadienoic acid",t:"Preservative",h:"none",p:"safe",d:"Naturally occurring fatty acid; considered one of the safest preservatives.",diet:{h:"y",k:"y",v:"y",vn:"y"},al:[]},
{c:"E202",n:"Potassium Sorbate",a:"Potassium 2,4-hexadienoate",t:"Preservative",h:"none",p:"safe",d:"Potassium salt of sorbic acid; one of the most commonly used preservatives globally.",diet:{h:"y",k:"y",v:"y",vn:"y"},al:[]},
{c:"E210",n:"Benzoic Acid",a:"Benzenecarboxylic acid",t:"Preservative",h:"moderate",p:"caution",d:"Can form benzene (a carcinogen) in the presence of vitamin C and heat.",diet:{h:"y",k:"y",v:"y",vn:"y"},al:["be"]},
{c:"E211",n:"Sodium Benzoate",a:"Benzoate of soda",t:"Preservative",h:"moderate",p:"caution",d:"Tested alongside the Southampton Six dyes in the 2007 Lancet hyperactivity study.",diet:{h:"y",k:"y",v:"y",vn:"y"},al:["be"]},
{c:"E220",n:"Sulphur Dioxide",a:"SO2, Sulfites",t:"Preservative",h:"low",p:"caution",d:"Common preservative in wine and dried fruit; can trigger asthma in sensitive individuals.",diet:{h:"y",k:"y",v:"y",vn:"y"},al:["su"]},
{c:"E223",n:"Sodium Metabisulphite",a:"Sodium pyrosulfite",t:"Preservative",h:"none",p:"caution",d:"Sulphite preservative that releases sulphur dioxide; can trigger asthma attacks.",diet:{h:"y",k:"y",v:"y",vn:"y"},al:["su"]},
{c:"E234",n:"Nisin",a:"Nisin A",t:"Preservative",h:"none",p:"safe",d:"Natural antimicrobial peptide produced by Lactococcus lactis bacteria.",diet:{h:"y",k:"y",v:"y",vn:"y"},al:[]},
{c:"E249",n:"Potassium Nitrite",a:"Saltpetre (archaic)",t:"Preservative",h:"none",p:"caution",d:"Nitrite salt in cured meats; can form carcinogenic nitrosamines during high-heat cooking.",diet:{h:"y",k:"y",v:"y",vn:"y"},al:["hi"]},
{c:"E250",n:"Sodium Nitrite",a:"Nitrite",t:"Preservative",h:"low",p:"caution",d:"Prevents botulism in cured meats but can form carcinogenic nitrosamines.",diet:{h:"y",k:"y",v:"y",vn:"y"},al:["hi"]},
{c:"E251",n:"Sodium Nitrate",a:"Chile saltpetre",t:"Preservative",h:"none",p:"caution",d:"Converts to nitrite in cured meats; same nitrosamine concerns apply.",diet:{h:"y",k:"y",v:"y",vn:"y"},al:["hi"]},
{c:"E252",n:"Potassium Nitrate",a:"Saltpetre, Niter",t:"Preservative",h:"none",p:"caution",d:"Traditional curing salt used for centuries; converts to nitrite in situ.",diet:{h:"y",k:"y",v:"y",vn:"y"},al:["hi"]},
{c:"E260",n:"Acetic Acid",a:"Ethanoic acid, Vinegar acid",t:"Acidity Regulator",h:"none",p:"safe",d:"The active component of vinegar; one of the oldest and safest food preservatives.",diet:{h:"y",k:"y",v:"y",vn:"y"},al:[]},
{c:"E270",n:"Lactic Acid",a:"Milk acid",t:"Acidity Regulator / Preservative",h:"none",p:"safe",d:"Naturally produced during fermentation; a normal human metabolite.",diet:{h:"y",k:"y",v:"y",vn:"y"},al:["da"]},
{c:"E280",n:"Propionic Acid",a:"Propanoic acid",t:"Preservative",h:"low",p:"generally-safe",d:"Naturally occurring short-chain fatty acid found in Swiss cheese.",diet:{h:"y",k:"y",v:"y",vn:"y"},al:[]},
{c:"E281",n:"Sodium Propionate",a:"Sodium propanoate",t:"Preservative",h:"low",p:"generally-safe",d:"Sodium salt of propionic acid used as a mould inhibitor in baked goods.",diet:{h:"y",k:"y",v:"y",vn:"y"},al:[]},
{c:"E282",n:"Calcium Propionate",a:"Calcium propanoate",t:"Preservative",h:"moderate",p:"generally-safe",d:"Bread mould inhibitor linked to irritability and restlessness in sensitive children.",diet:{h:"y",k:"y",v:"y",vn:"y"},al:[]},
{c:"E283",n:"Potassium Propionate",a:"Potassium propanoate",t:"Preservative",h:"low",p:"generally-safe",d:"Potassium salt of propionic acid; functionally equivalent to E282.",diet:{h:"y",k:"y",v:"y",vn:"y"},al:[]},
{c:"E296",n:"Malic Acid",a:"DL-malic acid",t:"Acidity Regulator",h:"none",p:"safe",d:"Naturally occurring organic acid found abundantly in apples.",diet:{h:"y",k:"y",v:"y",vn:"y"},al:[]},
{c:"E297",n:"Fumaric Acid",a:"Trans-butenedioic acid",t:"Acidity Regulator",h:"none",p:"safe",d:"Naturally occurring organic acid and an intermediate in the Krebs cycle.",diet:{h:"y",k:"y",v:"y",vn:"y"},al:[]},
{c:"E300",n:"Ascorbic Acid",a:"Vitamin C",t:"Antioxidant / Vitamin",h:"none",p:"safe",d:"Essential nutrient (vitamin C) used as an antioxidant preservative in food.",diet:{h:"y",k:"y",v:"y",vn:"y"},al:[]},
{c:"E301",n:"Sodium Ascorbate",a:"Sodium salt of ascorbic acid",t:"Antioxidant / Vitamin",h:"none",p:"safe",d:"Sodium salt of vitamin C; more water-soluble than ascorbic acid.",diet:{h:"y",k:"y",v:"y",vn:"y"},al:[]},
{c:"E306",n:"Tocopherols",a:"Mixed tocopherols, Vitamin E",t:"Antioxidant / Vitamin",h:"none",p:"safe",d:"Natural vitamin E mixture extracted from vegetable oils; essential antioxidant.",diet:{h:"y",k:"y",v:"y",vn:"y"},al:[]},
{c:"E307",n:"Alpha-Tocopherol",a:"Synthetic vitamin E",t:"Antioxidant / Vitamin",h:"none",p:"safe",d:"The most biologically active form of vitamin E; essential for fetal development.",diet:{h:"y",k:"y",v:"y",vn:"y"},al:[]},
{c:"E310",n:"Propyl Gallate",a:"Propyl 3,4,5-trihydroxybenzoate",t:"Antioxidant",h:"none",p:"caution",d:"Synthetic antioxidant preventing rancidity; incomplete reproductive toxicity data.",diet:{h:"y",k:"y",v:"y",vn:"y"},al:[]},
{c:"E316",n:"Sodium Erythorbate",a:"Sodium isoascorbate",t:"Antioxidant",h:"none",p:"safe",d:"Stereoisomer of sodium ascorbate functioning as an antioxidant in cured meats.",diet:{h:"y",k:"y",v:"y",vn:"y"},al:[]},
{c:"E319",n:"TBHQ",a:"tert-Butylhydroquinone",t:"Antioxidant",h:"none",p:"caution",d:"Synthetic antioxidant extending shelf life of oils; some high-dose animal concerns.",diet:{h:"y",k:"y",v:"y",vn:"y"},al:[]},
{c:"E320",n:"BHA",a:"Butylated Hydroxyanisole",t:"Antioxidant",h:"low",p:"caution",d:"IARC classifies as possibly carcinogenic (Group 2B); some endocrine disruption evidence.",diet:{h:"y",k:"y",v:"y",vn:"y"},al:[]},
{c:"E321",n:"BHT",a:"Butylated Hydroxytoluene",t:"Antioxidant",h:"low",p:"caution",d:"Synthetic antioxidant with mixed evidence — tumour promotion and anti-tumour effects.",diet:{h:"y",k:"y",v:"y",vn:"y"},al:[]},
{c:"E322",n:"Lecithin",a:"Soy lecithin, Sunflower lecithin",t:"Emulsifier",h:"none",p:"safe",d:"Natural emulsifier derived from soybeans, sunflower seeds, or eggs.",diet:{h:"y",k:"y",v:"y",vn:"dp"},al:["so"]},
{c:"E330",n:"Citric Acid",a:"2-hydroxypropane-1,2,3-tricarboxylic acid",t:"Acidity Regulator",h:"none",p:"safe",d:"Naturally occurs in citrus fruits; universally considered safe.",diet:{h:"y",k:"y",v:"y",vn:"y"},al:[]},
{c:"E331",n:"Sodium Citrate",a:"Trisodium citrate",t:"Acidity Regulator / Emulsifier",h:"none",p:"safe",d:"Sodium salt of citric acid used as an acidity regulator and emulsifier.",diet:{h:"y",k:"y",v:"y",vn:"y"},al:[]},
{c:"E334",n:"Tartaric Acid",a:"L-(+)-tartaric acid",t:"Acidity Regulator",h:"none",p:"safe",d:"Naturally occurring organic acid abundant in grapes and tamarinds.",diet:{h:"d",k:"y",v:"y",vn:"y"},al:[]},
{c:"E338",n:"Phosphoric Acid",a:"Orthophosphoric acid",t:"Acidity Regulator",h:"none",p:"generally-safe",d:"Used to acidify cola beverages; excessive intake may impair calcium absorption.",diet:{h:"y",k:"y",v:"y",vn:"y"},al:[]},
{c:"E339",n:"Sodium Phosphates",a:"Monosodium phosphate, Disodium phosphate",t:"Acidity Regulator / Emulsifier",h:"none",p:"generally-safe",d:"Sodium salts of phosphoric acid used as emulsifiers and buffering agents.",diet:{h:"y",k:"y",v:"y",vn:"y"},al:[]},
{c:"E341",n:"Calcium Phosphates",a:"Monocalcium phosphate, Dicalcium phosphate",t:"Acidity Regulator / Anti-caking Agent",h:"none",p:"safe",d:"Calcium salts of phosphoric acid; provides beneficial calcium and phosphorus.",diet:{h:"y",k:"y",v:"y",vn:"y"},al:[]},
{c:"E406",n:"Agar",a:"Agar-agar, Kanten",t:"Gelling Agent / Thickener",h:"none",p:"safe",d:"Natural polysaccharide from red seaweed; vegetarian gelatin alternative.",diet:{h:"y",k:"y",v:"y",vn:"y"},al:[]},
{c:"E407",n:"Carrageenan",a:"Irish moss extract",t:"Thickener / Stabiliser",h:"none",p:"caution",d:"Seaweed extract; some in vitro studies suggest potential inflammatory effects.",diet:{h:"y",k:"y",v:"y",vn:"y"},al:[]},
{c:"E410",n:"Locust Bean Gum",a:"Carob gum, LBG",t:"Thickener / Stabiliser",h:"none",p:"safe",d:"Natural polysaccharide from carob tree seeds; used in food for thousands of years.",diet:{h:"y",k:"y",v:"y",vn:"y"},al:[]},
{c:"E412",n:"Guar Gum",a:"Guaran",t:"Thickener / Stabiliser",h:"none",p:"safe",d:"Natural galactomannan from guar beans; safe at typical dietary levels.",diet:{h:"y",k:"y",v:"y",vn:"y"},al:[]},
{c:"E414",n:"Gum Arabic",a:"Acacia gum",t:"Emulsifier / Stabiliser",h:"none",p:"safe",d:"Natural tree exudate with prebiotic fibre properties; very well tolerated.",diet:{h:"y",k:"y",v:"y",vn:"y"},al:[]},
{c:"E415",n:"Xanthan Gum",a:"Corn sugar gum",t:"Thickener / Stabiliser",h:"none",p:"safe",d:"Produced by bacterial fermentation; essential in gluten-free baking.",diet:{h:"y",k:"y",v:"y",vn:"y"},al:[]},
{c:"E420",n:"Sorbitol",a:"D-glucitol, D-sorbitol",t:"Sweetener / Humectant",h:"none",p:"generally-safe",d:"Sugar alcohol naturally occurring in stone fruits; laxative effect above 20-50 g/day.",diet:{h:"y",k:"y",v:"y",vn:"y"},al:[]},
{c:"E421",n:"Mannitol",a:"D-mannitol, Manna sugar",t:"Sweetener / Anti-caking Agent",h:"none",p:"generally-safe",d:"Sugar alcohol naturally found in seaweeds and mushrooms.",diet:{h:"y",k:"y",v:"y",vn:"y"},al:[]},
{c:"E433",n:"Polysorbate 80",a:"Tween 80",t:"Emulsifier",h:"none",p:"caution",d:"Synthetic emulsifier; mouse studies found it may alter gut microbiota composition.",diet:{h:"dp",k:"dp",v:"dp",vn:"dp"},al:[]},
{c:"E440",n:"Pectin",a:"Apple pectin, Citrus pectin",t:"Gelling Agent",h:"none",p:"safe",d:"Natural polysaccharide fibre from fruit cell walls; used to set jams and jellies.",diet:{h:"y",k:"y",v:"y",vn:"y"},al:[]},
{c:"E450",n:"Diphosphates",a:"Pyrophosphates, SAPP",t:"Emulsifier / Raising Agent",h:"none",p:"generally-safe",d:"Phosphate salts used as raising agents in baking and emulsifiers in cheese.",diet:{h:"y",k:"y",v:"y",vn:"y"},al:[]},
{c:"E460",n:"Cellulose",a:"Microcrystalline cellulose, MCC",t:"Anti-caking Agent / Fibre",h:"none",p:"safe",d:"The most abundant organic polymer on Earth; functions as insoluble dietary fibre.",diet:{h:"y",k:"y",v:"y",vn:"y"},al:[]},
{c:"E466",n:"Carboxymethyl Cellulose",a:"CMC, Cellulose gum",t:"Thickener / Stabiliser",h:"none",p:"generally-safe",d:"Semi-synthetic polymer derived from cellulose; emerging microbiome disruption evidence.",diet:{h:"y",k:"y",v:"y",vn:"y"},al:[]},
{c:"E471",n:"Mono- and Diglycerides",a:"Glyceryl monostearate, GMS",t:"Emulsifier",h:"none",p:"safe",d:"Emulsifiers chemically identical to partial glycerides formed during fat digestion.",diet:{h:"dp",k:"dp",v:"dp",vn:"dp"},al:[]},
{c:"E472e",n:"DATEM",a:"Diacetyl tartaric acid esters",t:"Emulsifier / Dough Conditioner",h:"none",p:"safe",d:"Effective dough conditioner that strengthens gluten networks for improved bread.",diet:{h:"dp",k:"dp",v:"dp",vn:"dp"},al:[]},
{c:"E476",n:"Polyglycerol Polyricinoleate",a:"PGPR",t:"Emulsifier",h:"none",p:"safe",d:"Emulsifier made from polyglycerol and castor oil; primarily used in chocolate.",diet:{h:"y",k:"y",v:"y",vn:"y"},al:[]},
{c:"E481",n:"Sodium Stearoyl Lactylate",a:"SSL",t:"Emulsifier / Dough Conditioner",h:"none",p:"safe",d:"Emulsifier made from stearic acid and lactic acid; excellent dough strengthener.",diet:{h:"dp",k:"dp",v:"dp",vn:"dp"},al:[]},
{c:"E500",n:"Sodium Bicarbonate",a:"Baking soda, NaHCO3",t:"Raising Agent / Acidity Regulator",h:"none",p:"safe",d:"One of the most widely used and oldest food additives; the essential leavening agent.",diet:{h:"y",k:"y",v:"y",vn:"y"},al:[]},
{c:"E508",n:"Potassium Chloride",a:"KCl, Potassium salt",t:"Flavour Enhancer / Salt Substitute",h:"none",p:"safe",d:"Essential mineral salt used as a reduced-sodium salt substitute.",diet:{h:"y",k:"y",v:"y",vn:"y"},al:[]},
{c:"E509",n:"Calcium Chloride",a:"CaCl2",t:"Firming Agent / Sequestrant",h:"none",p:"safe",d:"Calcium salt used as a firming agent in canned vegetables and tofu coagulant.",diet:{h:"y",k:"y",v:"y",vn:"y"},al:[]},
{c:"E516",n:"Calcium Sulphate",a:"Gypsum, CaSO4",t:"Firming Agent / Flour Treatment Agent",h:"none",p:"safe",d:"Natural mineral used for centuries as a tofu coagulant and flour treatment agent.",diet:{h:"y",k:"y",v:"y",vn:"y"},al:[]},
{c:"E536",n:"Potassium Ferrocyanide",a:"Yellow prussiate of potash",t:"Anti-caking Agent",h:"none",p:"safe",d:"Anti-caking agent in salt; cyanide groups are tightly bound and not released in the body.",diet:{h:"y",k:"y",v:"y",vn:"y"},al:[]},
{c:"E551",n:"Silicon Dioxide",a:"Silica, SiO2",t:"Anti-caking Agent",h:"none",p:"safe",d:"Natural mineral (quartz) preventing clumping in powdered foods; passes through unabsorbed.",diet:{h:"y",k:"y",v:"y",vn:"y"},al:[]},
{c:"E553b",n:"Talc",a:"Magnesium silicate",t:"Anti-caking Agent / Glazing Agent",h:"none",p:"generally-safe",d:"Natural mineral used as an anti-caking agent; food-grade must be asbestos-free.",diet:{h:"y",k:"y",v:"y",vn:"y"},al:[]},
{c:"E575",n:"Glucono Delta-Lactone",a:"GDL, Gluconolactone",t:"Acidity Regulator / Sequestrant",h:"none",p:"safe",d:"Naturally occurring substance formed from glucose; ideal for tofu coagulation.",diet:{h:"y",k:"y",v:"y",vn:"y"},al:[]},
{c:"E621",n:"Monosodium Glutamate",a:"MSG, Vetsin",t:"Flavour Enhancer",h:"low",p:"generally-safe",d:"Naturally occurring amino acid found in tomatoes, parmesan, and mushrooms.",diet:{h:"y",k:"y",v:"y",vn:"y"},al:["hi"]},
{c:"E901",n:"Beeswax",a:"Cera alba",t:"Glazing Agent",h:"none",p:"safe",d:"Natural wax produced by honey bees; not digestible, passes through the GI tract.",diet:{h:"y",k:"y",v:"y",vn:"n"},al:[]},
{c:"E903",n:"Carnauba Wax",a:"Brazil wax, Palm wax",t:"Glazing Agent",h:"none",p:"safe",d:"Natural wax from carnauba palm leaves; not digestible, passes through GI tract.",diet:{h:"y",k:"y",v:"y",vn:"y"},al:[]},
{c:"E904",n:"Shellac",a:"Confectioner's glaze, Lac resin",t:"Glazing Agent",h:"none",p:"safe",d:"Natural resin from the lac insect; functions as an inert, non-absorbed coating.",diet:{h:"d",k:"d",v:"n",vn:"n"},al:[]},
{c:"E920",n:"L-Cysteine",a:"Cysteine",t:"Flour Treatment Agent",h:"none",p:"safe",d:"Amino acid flour treatment agent improving dough extensibility; fully metabolised.",diet:{h:"dp",k:"dp",v:"dp",vn:"dp"},al:[]},
{c:"E950",n:"Acesulfame K",a:"Ace-K, Acesulfame Potassium",t:"Artificial Sweetener",h:"low",p:"caution",d:"200x sweeter than sugar; crosses the placenta and detected in breast milk.",diet:{h:"y",k:"y",v:"y",vn:"y"},al:[]},
{c:"E951",n:"Aspartame",a:"NutraSweet, Equal",t:"Artificial Sweetener",h:"low",p:"caution",d:"200x sweeter than sugar; IARC classified as possibly carcinogenic (Group 2B) in 2023.",diet:{h:"y",k:"y",v:"y",vn:"y"},al:[]},
{c:"E953",n:"Isomalt",a:"Palatinit",t:"Sweetener / Bulking Agent",h:"none",p:"generally-safe",d:"Sugar alcohol derived from sucrose; low glycaemic index, tooth-friendly.",diet:{h:"y",k:"y",v:"y",vn:"y"},al:[]},
{c:"E954",n:"Saccharin",a:"Benzoic sulphimide",t:"Artificial Sweetener",h:"none",p:"caution",d:"Oldest artificial sweetener (1879); crosses the placenta and accumulates in fetal tissue.",diet:{h:"y",k:"y",v:"y",vn:"y"},al:[]},
{c:"E955",n:"Sucralose",a:"Splenda",t:"Artificial Sweetener",h:"low",p:"caution",d:"600x sweeter than sugar; emerging research on gut microbiome disruption.",diet:{h:"y",k:"y",v:"y",vn:"y"},al:[]},
{c:"E960",n:"Steviol Glycosides",a:"Stevia, Reb A, Reb M",t:"Natural Sweetener",h:"none",p:"safe",d:"Natural high-intensity sweetener from the Stevia plant; 200-300x sweeter than sugar.",diet:{h:"y",k:"y",v:"y",vn:"y"},al:[]},
{c:"E961",n:"Neotame",a:"Newtame",t:"Artificial Sweetener",h:"none",p:"caution",d:"High-intensity sweetener 7,000-13,000x sweeter than sugar; very limited pregnancy data.",diet:{h:"y",k:"y",v:"y",vn:"y"},al:[]},
{c:"E962",n:"Aspartame-Acesulfame Salt",a:"TwinSweet",t:"Artificial Sweetener",h:"low",p:"caution",d:"Combined salt of aspartame and acesulfame K; same concerns as both component sweeteners.",diet:{h:"y",k:"y",v:"y",vn:"y"},al:[]},
{c:"E965",n:"Maltitol",a:"Hydrogenated maltose",t:"Sweetener / Bulking Agent",h:"none",p:"generally-safe",d:"Sugar alcohol closest to sugar in taste; lower glycaemic response than sucrose.",diet:{h:"y",k:"y",v:"y",vn:"y"},al:[]},
{c:"E966",n:"Lactitol",a:"Lactitol monohydrate",t:"Sweetener / Bulking Agent",h:"none",p:"generally-safe",d:"Sugar alcohol from lactose with prebiotic properties promoting beneficial bacteria.",diet:{h:"y",k:"y",v:"y",vn:"n"},al:["da"]},
{c:"E967",n:"Xylitol",a:"Birch sugar, Wood sugar",t:"Sweetener",h:"none",p:"safe",d:"Sugar alcohol with documented anti-cavity benefits; toxic to dogs.",diet:{h:"y",k:"y",v:"y",vn:"y"},al:[]},
{c:"E968",n:"Erythritol",a:"Meso-erythritol",t:"Sweetener / Humectant",h:"none",p:"generally-safe",d:"Lowest calorie sugar alcohol (0.2 kcal/g); no laxative effect at normal doses.",diet:{h:"y",k:"y",v:"y",vn:"y"},al:[]},
{c:"E1442",n:"Hydroxypropyl Distarch Phosphate",a:"Modified starch, HDP starch",t:"Modified Starch / Thickener",h:"none",p:"safe",d:"Most commonly used modified starch; digested by amylase like native starch.",diet:{h:"y",k:"y",v:"y",vn:"y"},al:[]},
{c:"E1520",n:"Propylene Glycol",a:"1,2-propanediol, PG",t:"Humectant / Solvent",h:"none",p:"caution",d:"Synthetic humectant and flavouring solvent; can cross the placenta.",diet:{h:"y",k:"y",v:"y",vn:"y"},al:[]}
];

  /* ── Styles ── */
  var CSS = `
/* FLR Additive Checker Widget — Scoped Styles */
.flr-widget *,
.flr-widget *::before,
.flr-widget *::after {
  box-sizing: border-box;
  margin: 0;
  padding: 0;
}
.flr-widget {
  --flr-green: #1B4332;
  --flr-green-light: #2D6A4F;
  --flr-terra: #D4956A;
  --flr-bg: #FFFFFF;
  --flr-bg2: #F8F9FA;
  --flr-bg3: #F1F3F5;
  --flr-text: #1A1A1A;
  --flr-text2: #555;
  --flr-text3: #888;
  --flr-border: #E0E0E0;
  --flr-shadow: 0 2px 12px rgba(0,0,0,0.08);
  --flr-shadow-lg: 0 8px 30px rgba(0,0,0,0.12);
  --flr-radius: 12px;
  --flr-radius-sm: 8px;
  --flr-font: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Helvetica Neue', sans-serif;
  font-family: var(--flr-font);
  font-size: 15px;
  line-height: 1.5;
  color: var(--flr-text);
  width: 100%;
  max-width: var(--flr-max-w, 420px);
  position: relative;
}
.flr-widget.flr-dark {
  --flr-bg: #1A1A2E;
  --flr-bg2: #16213E;
  --flr-bg3: #0F3460;
  --flr-text: #E8E8E8;
  --flr-text2: #B0B0B0;
  --flr-text3: #888;
  --flr-border: #2A2A4A;
  --flr-shadow: 0 2px 12px rgba(0,0,0,0.3);
  --flr-shadow-lg: 0 8px 30px rgba(0,0,0,0.4);
}

/* Container */
.flr-container {
  background: var(--flr-bg);
  border: 1px solid var(--flr-border);
  border-radius: var(--flr-radius);
  box-shadow: var(--flr-shadow);
  overflow: visible;
  position: relative;
}

/* Header */
.flr-header {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 14px 16px 10px;
  border-bottom: 1px solid var(--flr-border);
}
.flr-header svg {
  flex-shrink: 0;
}
.flr-header-text {
  font-size: 14px;
  font-weight: 700;
  color: var(--flr-green);
  letter-spacing: -0.01em;
}
.flr-dark .flr-header-text {
  color: #52B788;
}

/* Search */
.flr-search-wrap {
  padding: 12px 16px;
  position: relative;
}
.flr-search-icon {
  position: absolute;
  left: 28px;
  top: 50%;
  transform: translateY(-50%);
  color: var(--flr-text3);
  pointer-events: none;
}
.flr-search {
  width: 100%;
  padding: 10px 14px 10px 38px;
  border: 1.5px solid var(--flr-border);
  border-radius: var(--flr-radius-sm);
  background: var(--flr-bg2);
  color: var(--flr-text);
  font-family: var(--flr-font);
  font-size: 14px;
  outline: none;
  transition: border-color 0.2s, box-shadow 0.2s;
}
.flr-search::placeholder {
  color: var(--flr-text3);
}
.flr-search:focus {
  border-color: var(--flr-green);
  box-shadow: 0 0 0 3px rgba(27,67,50,0.1);
}
.flr-dark .flr-search:focus {
  box-shadow: 0 0 0 3px rgba(82,183,136,0.15);
}

/* Dropdown */
.flr-dropdown {
  position: absolute;
  left: 16px;
  right: 16px;
  top: 100%;
  z-index: 9999;
  background: var(--flr-bg);
  border: 1px solid var(--flr-border);
  border-radius: var(--flr-radius-sm);
  box-shadow: var(--flr-shadow-lg);
  max-height: 0;
  overflow: hidden;
  opacity: 0;
  transition: max-height 0.25s ease, opacity 0.2s ease;
}
.flr-dropdown.flr-open {
  max-height: 320px;
  opacity: 1;
  overflow-y: auto;
}
.flr-dropdown-item {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 10px 14px;
  cursor: pointer;
  border-bottom: 1px solid var(--flr-border);
  transition: background 0.15s;
}
.flr-dropdown-item:last-child {
  border-bottom: none;
}
.flr-dropdown-item:hover {
  background: var(--flr-bg2);
}
.flr-dd-code {
  font-size: 12px;
  font-weight: 700;
  color: var(--flr-green);
  background: var(--flr-bg3);
  padding: 2px 7px;
  border-radius: 4px;
  white-space: nowrap;
}
.flr-dark .flr-dd-code {
  color: #52B788;
  background: var(--flr-bg3);
}
.flr-dd-name {
  font-size: 13px;
  font-weight: 600;
  color: var(--flr-text);
  flex: 1;
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.flr-dd-badges {
  display: flex;
  gap: 4px;
  flex-shrink: 0;
}
.flr-dd-dot {
  width: 8px;
  height: 8px;
  border-radius: 50%;
  flex-shrink: 0;
}

/* Detail card */
.flr-detail {
  display: none;
  padding: 16px;
  animation: flr-fadeIn 0.3s ease;
}
.flr-detail.flr-show {
  display: block;
}
@keyframes flr-fadeIn {
  from { opacity: 0; transform: translateY(6px); }
  to { opacity: 1; transform: translateY(0); }
}
.flr-detail-header {
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  margin-bottom: 12px;
}
.flr-detail-title {
  display: flex;
  align-items: center;
  gap: 8px;
  flex-wrap: wrap;
}
.flr-detail-code {
  font-size: 18px;
  font-weight: 800;
  color: var(--flr-green);
}
.flr-dark .flr-detail-code {
  color: #52B788;
}
.flr-detail-name {
  font-size: 17px;
  font-weight: 700;
  color: var(--flr-text);
}
.flr-detail-close {
  background: none;
  border: none;
  cursor: pointer;
  color: var(--flr-text3);
  padding: 4px;
  border-radius: 6px;
  transition: background 0.15s, color 0.15s;
  display: flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
}
.flr-detail-close:hover {
  background: var(--flr-bg3);
  color: var(--flr-text);
}
.flr-detail-cat {
  font-size: 12px;
  color: var(--flr-text2);
  margin-bottom: 14px;
  padding: 4px 10px;
  background: var(--flr-bg2);
  border-radius: 20px;
  display: inline-block;
}
.flr-badges-row {
  display: flex;
  gap: 8px;
  margin-bottom: 14px;
  flex-wrap: wrap;
}
.flr-badge {
  display: inline-flex;
  align-items: center;
  gap: 5px;
  padding: 5px 10px;
  border-radius: 6px;
  font-size: 12px;
  font-weight: 600;
  line-height: 1;
}
.flr-badge-label {
  opacity: 0.8;
  font-weight: 500;
  text-transform: uppercase;
  font-size: 10px;
  letter-spacing: 0.03em;
}
.flr-badge-adhd-high { background: #DC2626; color: #fff; }
.flr-badge-adhd-moderate { background: #F59E0B; color: #1A1A1A; }
.flr-badge-adhd-low { background: #EAB308; color: #1A1A1A; }
.flr-badge-adhd-none { background: #16A34A; color: #fff; }
.flr-badge-preg-avoid { background: #DC2626; color: #fff; }
.flr-badge-preg-caution { background: #F59E0B; color: #1A1A1A; }
.flr-badge-preg-generally-safe { background: #16A34A; color: #fff; }
.flr-badge-preg-safe { background: #16A34A; color: #fff; }

.flr-desc {
  font-size: 13.5px;
  color: var(--flr-text2);
  line-height: 1.55;
  margin-bottom: 14px;
}
.flr-cta {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  color: var(--flr-green);
  font-size: 13px;
  font-weight: 600;
  text-decoration: none;
  padding: 8px 14px;
  border: 1.5px solid var(--flr-green);
  border-radius: var(--flr-radius-sm);
  transition: background 0.2s, color 0.2s;
}
.flr-cta:hover {
  background: var(--flr-green);
  color: #fff;
}
.flr-dark .flr-cta {
  color: #52B788;
  border-color: #52B788;
}
.flr-dark .flr-cta:hover {
  background: #52B788;
  color: #1A1A2E;
}

/* Footer */
.flr-footer {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 5px;
  padding: 10px 16px;
  border-top: 1px solid var(--flr-border);
  font-size: 11px;
  color: var(--flr-text3);
}
.flr-footer a {
  color: var(--flr-green);
  text-decoration: none;
  font-weight: 600;
}
.flr-dark .flr-footer a {
  color: #52B788;
}
.flr-footer a:hover {
  text-decoration: underline;
}

/* Dietary suitability row */
.flr-diet-row {
  display: flex;
  gap: 6px;
  margin-bottom: 14px;
  flex-wrap: wrap;
}
.flr-diet-item {
  display: inline-flex;
  align-items: center;
  gap: 4px;
  font-size: 11.5px;
  font-weight: 600;
  padding: 4px 9px;
  border-radius: 6px;
  background: var(--flr-bg2);
  border: 1px solid var(--flr-border);
  color: var(--flr-text);
}
.flr-diet-icon-y { color: #16A34A; }
.flr-diet-icon-n { color: #DC2626; }
.flr-diet-icon-d { color: #F59E0B; }
.flr-diet-label {
  font-size: 10px;
  font-weight: 500;
  text-transform: uppercase;
  letter-spacing: 0.03em;
  opacity: 0.8;
}

/* Allergy alert row */
.flr-allergy-row {
  display: flex;
  align-items: center;
  gap: 6px;
  margin-bottom: 14px;
  padding: 6px 10px;
  border-radius: 6px;
  background: rgba(220,38,38,0.08);
  border: 1px solid rgba(220,38,38,0.18);
  font-size: 12px;
  font-weight: 600;
  color: #B91C1C;
}
.flr-dark .flr-allergy-row {
  background: rgba(220,38,38,0.12);
  border-color: rgba(220,38,38,0.25);
  color: #FCA5A5;
}
.flr-allergy-icon {
  flex-shrink: 0;
  font-size: 14px;
}

/* Empty state */
.flr-empty {
  padding: 20px 14px;
  text-align: center;
  font-size: 13px;
  color: var(--flr-text3);
}
`;

  /* ── Helpers ── */
  function escHtml(s) {
    var d = document.createElement('div');
    d.appendChild(document.createTextNode(s));
    return d.innerHTML;
  }

  function adhdLabel(v) {
    return { high: 'High Risk', moderate: 'Moderate', low: 'Low Risk', none: 'None' }[v] || v;
  }
  function pregLabel(v) {
    return { avoid: 'Avoid', caution: 'Caution', 'generally-safe': 'Generally Safe', safe: 'Safe' }[v] || v;
  }

  function dietIcon(v) {
    if (v === 'y') return '<span class="flr-diet-icon-y">&#10003;</span>';
    if (v === 'n') return '<span class="flr-diet-icon-n">&#10007;</span>';
    return '<span class="flr-diet-icon-d">?</span>';
  }

  function dotColor(v, type) {
    if (type === 'adhd') {
      return { high: '#DC2626', moderate: '#F59E0B', low: '#EAB308', none: '#16A34A' }[v] || '#ccc';
    }
    return { avoid: '#DC2626', caution: '#F59E0B', 'generally-safe': '#16A34A', safe: '#16A34A' }[v] || '#ccc';
  }

  /* ── Init ── */
  function init() {
    var root = document.getElementById('flr-additive-checker');
    if (!root) return;

    var theme = root.getAttribute('data-theme') || '';
    var maxW = parseInt(root.getAttribute('data-width'), 10) || 420;

    /* Inject CSS */
    if (!document.getElementById('flr-widget-styles')) {
      var style = document.createElement('style');
      style.id = 'flr-widget-styles';
      style.textContent = CSS;
      document.head.appendChild(style);
    }

    /* Build widget */
    var widget = document.createElement('div');
    widget.className = 'flr-widget' + (theme === 'dark' ? ' flr-dark' : '');
    widget.style.setProperty('--flr-max-w', maxW + 'px');

    widget.innerHTML =
      '<div class="flr-container">' +
        /* Header */
        '<div class="flr-header">' +
          '<svg width="24" height="24" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">' +
            '<rect width="48" height="48" rx="10" fill="#1B4332"/>' +
            '<path d="M14 12h20c1.1 0 2 .9 2 2v20c0 1.1-.9 2-2 2H14c-1.1 0-2-.9-2-2V14c0-1.1.9-2 2-2z" fill="none" stroke="#fff" stroke-width="2"/>' +
            '<rect x="16" y="17" width="16" height="2" rx="1" fill="#D4956A"/>' +
            '<rect x="16" y="22" width="12" height="2" rx="1" fill="#fff" opacity=".7"/>' +
            '<rect x="16" y="27" width="14" height="2" rx="1" fill="#fff" opacity=".5"/>' +
            '<rect x="16" y="32" width="10" height="2" rx="1" fill="#fff" opacity=".3"/>' +
          '</svg>' +
          '<span class="flr-header-text">FoodLabelReader</span>' +
        '</div>' +
        /* Search */
        '<div class="flr-search-wrap">' +
          '<div class="flr-search-icon">' +
            '<svg width="16" height="16" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">' +
              '<circle cx="7" cy="7" r="4.5"/><path d="M10.5 10.5L14 14"/>' +
            '</svg>' +
          '</div>' +
          '<input type="text" class="flr-search" placeholder="Search E-numbers or additives…" autocomplete="off" spellcheck="false"/>' +
          '<div class="flr-dropdown" id="flr-dd"></div>' +
        '</div>' +
        /* Detail card (hidden initially) */
        '<div class="flr-detail" id="flr-detail"></div>' +
        /* Footer */
        '<div class="flr-footer">' +
          'Powered by <a href="https://foodlabelreader.com" target="_blank" rel="noopener">FoodLabelReader.com</a>' +
        '</div>' +
      '</div>';

    root.innerHTML = '';
    root.appendChild(widget);

    /* References */
    var input = widget.querySelector('.flr-search');
    var dd = widget.querySelector('#flr-dd');
    var detailEl = widget.querySelector('#flr-detail');

    /* Search handler */
    input.addEventListener('input', function () {
      var q = input.value.trim().toLowerCase();
      hideDetail();
      if (q.length < 1) {
        closeDropdown();
        return;
      }
      var matches = D.filter(function (a) {
        return a.c.toLowerCase().indexOf(q) !== -1 ||
               a.n.toLowerCase().indexOf(q) !== -1 ||
               a.a.toLowerCase().indexOf(q) !== -1;
      }).slice(0, 5);

      if (matches.length === 0) {
        dd.innerHTML = '<div class="flr-empty">No additives found</div>';
        openDropdown();
        return;
      }
      dd.innerHTML = matches.map(function (a) {
        return '<div class="flr-dropdown-item" data-code="' + a.c + '">' +
          '<span class="flr-dd-code">' + escHtml(a.c) + '</span>' +
          '<span class="flr-dd-name">' + escHtml(a.n) + '</span>' +
          '<span class="flr-dd-badges">' +
            '<span class="flr-dd-dot" style="background:' + dotColor(a.h, 'adhd') + '" title="ADHD: ' + adhdLabel(a.h) + '"></span>' +
            '<span class="flr-dd-dot" style="background:' + dotColor(a.p, 'preg') + '" title="Pregnancy: ' + pregLabel(a.p) + '"></span>' +
          '</span>' +
        '</div>';
      }).join('');
      openDropdown();
    });

    /* Click result */
    dd.addEventListener('click', function (e) {
      var item = e.target.closest('.flr-dropdown-item');
      if (!item) return;
      var code = item.getAttribute('data-code');
      var a = D.filter(function (x) { return x.c === code; })[0];
      if (a) showDetail(a);
      closeDropdown();
    });

    /* Close dropdown on outside click */
    document.addEventListener('click', function (e) {
      if (!widget.contains(e.target)) {
        closeDropdown();
      }
    });

    /* Keyboard: Escape to close */
    input.addEventListener('keydown', function (e) {
      if (e.key === 'Escape') {
        closeDropdown();
        input.blur();
      }
    });

    function openDropdown() { dd.classList.add('flr-open'); }
    function closeDropdown() { dd.classList.remove('flr-open'); }

    function showDetail(a) {
      var adhdCls = 'flr-badge-adhd-' + a.h;
      var pregCls = 'flr-badge-preg-' + a.p;

      detailEl.innerHTML =
        '<div class="flr-detail-header">' +
          '<div class="flr-detail-title">' +
            '<span class="flr-detail-code">' + escHtml(a.c) + '</span>' +
            '<span class="flr-detail-name">' + escHtml(a.n) + '</span>' +
          '</div>' +
          '<button class="flr-detail-close" aria-label="Close" id="flr-close-btn">' +
            '<svg width="18" height="18" viewBox="0 0 18 18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M5 5l8 8M13 5l-8 8"/></svg>' +
          '</button>' +
        '</div>' +
        '<div class="flr-detail-cat">' + escHtml(a.t) + '</div>' +
        '<div class="flr-badges-row">' +
          '<span class="flr-badge ' + adhdCls + '">' +
            '<span class="flr-badge-label">ADHD</span>' + escHtml(adhdLabel(a.h)) +
          '</span>' +
          '<span class="flr-badge ' + pregCls + '">' +
            '<span class="flr-badge-label">Pregnancy</span>' + escHtml(pregLabel(a.p)) +
          '</span>' +
        '</div>' +
        '<div class="flr-diet-row">' +
          '<span class="flr-diet-item">' + dietIcon(a.diet.h) + ' <span class="flr-diet-label">Halal</span></span>' +
          '<span class="flr-diet-item">' + dietIcon(a.diet.k) + ' <span class="flr-diet-label">Kosher</span></span>' +
          '<span class="flr-diet-item">' + dietIcon(a.diet.v) + ' <span class="flr-diet-label">Vegetarian</span></span>' +
          '<span class="flr-diet-item">' + dietIcon(a.diet.vn) + ' <span class="flr-diet-label">Vegan</span></span>' +
        '</div>' +
        (a.al && a.al.length ? '<div class="flr-allergy-row"><span class="flr-allergy-icon">&#9888;</span> Allergy: ' + a.al.map(function(x){return({su:"Sulphites",az:"Azo/Aspirin",be:"Benzoates",so:"Soy",da:"Dairy",hi:"Histamine"})[x]||x;}).join(', ') + '</div>' : '') +
        '<p class="flr-desc">' + escHtml(a.d) + '</p>' +
        '<a class="flr-cta" href="https://foodlabelreader.com/tool-additive-search.html" target="_blank" rel="noopener">' +
          'View full details →' +
        '</a>';

      detailEl.classList.add('flr-show');

      widget.querySelector('#flr-close-btn').addEventListener('click', function () {
        hideDetail();
      });
    }

    function hideDetail() {
      detailEl.classList.remove('flr-show');
      detailEl.innerHTML = '';
    }
  }

  /* ── Boot ── */
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
