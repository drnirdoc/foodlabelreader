/**
 * FoodLabelReader Safety Badge Widget v1.0
 * Embeddable additive safety rating badge/card
 * https://foodlabelreader.com
 *
 * Usage:
 *   <div class="flr-safety-badge" data-additive="E102"></div>
 *   <script src="https://foodlabelreader.com/widgets/safety-badge.js"></script>
 *
 * Options:
 *   data-theme="dark"        Dark background variant
 *   data-style="compact"     Inline pill badge (~180px)
 *   data-style="card"        Card mode (default, ~200px)
 */
(function () {
  "use strict";

  if (window.__flrSafetyBadgeLoaded) return;
  window.__flrSafetyBadgeLoaded = true;

  /* ── Additive data (code, name, cat, adhd, preg) ── */
  var D = [
    { c: "E102", n: "Tartrazine", cat: "Artificial Colour", a: "high", p: "caution", diet:{h:"y",k:"y",v:"y",vn:"y"}, al:["az"] },
    { c: "E104", n: "Quinoline Yellow", cat: "Artificial Colour", a: "high", p: "caution", diet:{h:"y",k:"y",v:"y",vn:"y"}, al:[] },
    { c: "E110", n: "Sunset Yellow", cat: "Artificial Colour", a: "high", p: "caution", diet:{h:"y",k:"y",v:"y",vn:"y"}, al:["az"] },
    { c: "E120", n: "Carmine", cat: "Natural Colour", a: "none", p: "generally-safe", diet:{h:"d",k:"n",v:"n",vn:"n"}, al:[] },
    { c: "E122", n: "Carmoisine", cat: "Artificial Colour", a: "high", p: "caution", diet:{h:"y",k:"y",v:"y",vn:"y"}, al:["az"] },
    { c: "E124", n: "Ponceau 4R", cat: "Artificial Colour", a: "high", p: "caution", diet:{h:"y",k:"y",v:"y",vn:"y"}, al:["az"] },
    { c: "E127", n: "Erythrosine", cat: "Artificial Colour", a: "low", p: "caution", diet:{h:"y",k:"y",v:"y",vn:"y"}, al:[] },
    { c: "E129", n: "Allura Red", cat: "Artificial Colour", a: "high", p: "caution", diet:{h:"y",k:"y",v:"y",vn:"y"}, al:["az"] },
    { c: "E131", n: "Patent Blue V", cat: "Artificial Colour", a: "none", p: "generally-safe", diet:{h:"y",k:"y",v:"y",vn:"y"}, al:[] },
    { c: "E132", n: "Indigo Carmine", cat: "Artificial Colour", a: "none", p: "generally-safe", diet:{h:"y",k:"y",v:"y",vn:"y"}, al:[] },
    { c: "E133", n: "Brilliant Blue", cat: "Artificial Colour", a: "moderate", p: "caution", diet:{h:"y",k:"y",v:"y",vn:"y"}, al:[] },
    { c: "E142", n: "Green S", cat: "Artificial Colour", a: "low", p: "caution", diet:{h:"y",k:"y",v:"y",vn:"y"}, al:[] },
    { c: "E150a", n: "Plain Caramel", cat: "Natural Colour", a: "none", p: "safe", diet:{h:"y",k:"y",v:"y",vn:"y"}, al:[] },
    { c: "E150d", n: "Sulphite Ammonia Caramel", cat: "Colour", a: "low", p: "caution", diet:{h:"y",k:"y",v:"y",vn:"y"}, al:[] },
    { c: "E151", n: "Brilliant Black BN", cat: "Artificial Colour", a: "low", p: "caution", diet:{h:"y",k:"y",v:"y",vn:"y"}, al:["az"] },
    { c: "E155", n: "Brown HT", cat: "Artificial Colour", a: "low", p: "caution", diet:{h:"y",k:"y",v:"y",vn:"y"}, al:["az"] },
    { c: "E160a", n: "Beta-Carotene", cat: "Natural Colour", a: "none", p: "safe", diet:{h:"y",k:"y",v:"y",vn:"y"}, al:[] },
    { c: "E160b", n: "Annatto", cat: "Natural Colour", a: "moderate", p: "generally-safe", diet:{h:"y",k:"y",v:"y",vn:"y"}, al:[] },
    { c: "E160c", n: "Paprika Extract", cat: "Natural Colour", a: "none", p: "safe", diet:{h:"y",k:"y",v:"y",vn:"y"}, al:[] },
    { c: "E162", n: "Beetroot Red", cat: "Natural Colour", a: "none", p: "safe", diet:{h:"y",k:"y",v:"y",vn:"y"}, al:[] },
    { c: "E163", n: "Anthocyanins", cat: "Natural Colour", a: "none", p: "safe", diet:{h:"y",k:"y",v:"y",vn:"y"}, al:[] },
    { c: "E171", n: "Titanium Dioxide", cat: "Colour / Whitener", a: "low", p: "avoid", diet:{h:"y",k:"y",v:"y",vn:"y"}, al:[] },
    { c: "E200", n: "Sorbic Acid", cat: "Preservative", a: "none", p: "safe", diet:{h:"y",k:"y",v:"y",vn:"y"}, al:[] },
    { c: "E202", n: "Potassium Sorbate", cat: "Preservative", a: "none", p: "safe", diet:{h:"y",k:"y",v:"y",vn:"y"}, al:[] },
    { c: "E210", n: "Benzoic Acid", cat: "Preservative", a: "moderate", p: "caution", diet:{h:"y",k:"y",v:"y",vn:"y"}, al:["be"] },
    { c: "E211", n: "Sodium Benzoate", cat: "Preservative", a: "moderate", p: "caution", diet:{h:"y",k:"y",v:"y",vn:"y"}, al:["be"] },
    { c: "E220", n: "Sulphur Dioxide", cat: "Preservative", a: "low", p: "caution", diet:{h:"y",k:"y",v:"y",vn:"y"}, al:["su"] },
    { c: "E223", n: "Sodium Metabisulphite", cat: "Preservative", a: "none", p: "caution", diet:{h:"y",k:"y",v:"y",vn:"y"}, al:["su"] },
    { c: "E234", n: "Nisin", cat: "Preservative", a: "none", p: "safe", diet:{h:"y",k:"y",v:"y",vn:"y"}, al:[] },
    { c: "E249", n: "Potassium Nitrite", cat: "Preservative", a: "none", p: "caution", diet:{h:"y",k:"y",v:"y",vn:"y"}, al:["hi"] },
    { c: "E250", n: "Sodium Nitrite", cat: "Preservative", a: "low", p: "caution", diet:{h:"y",k:"y",v:"y",vn:"y"}, al:["hi"] },
    { c: "E251", n: "Sodium Nitrate", cat: "Preservative", a: "none", p: "caution", diet:{h:"y",k:"y",v:"y",vn:"y"}, al:["hi"] },
    { c: "E252", n: "Potassium Nitrate", cat: "Preservative", a: "none", p: "caution", diet:{h:"y",k:"y",v:"y",vn:"y"}, al:["hi"] },
    { c: "E260", n: "Acetic Acid", cat: "Acidity Regulator", a: "none", p: "safe", diet:{h:"y",k:"y",v:"y",vn:"y"}, al:[] },
    { c: "E270", n: "Lactic Acid", cat: "Acidity Regulator / Preservative", a: "none", p: "safe", diet:{h:"y",k:"y",v:"y",vn:"y"}, al:["da"] },
    { c: "E280", n: "Propionic Acid", cat: "Preservative", a: "low", p: "generally-safe", diet:{h:"y",k:"y",v:"y",vn:"y"}, al:[] },
    { c: "E281", n: "Sodium Propionate", cat: "Preservative", a: "low", p: "generally-safe", diet:{h:"y",k:"y",v:"y",vn:"y"}, al:[] },
    { c: "E282", n: "Calcium Propionate", cat: "Preservative", a: "moderate", p: "generally-safe", diet:{h:"y",k:"y",v:"y",vn:"y"}, al:[] },
    { c: "E283", n: "Potassium Propionate", cat: "Preservative", a: "low", p: "generally-safe", diet:{h:"y",k:"y",v:"y",vn:"y"}, al:[] },
    { c: "E296", n: "Malic Acid", cat: "Acidity Regulator", a: "none", p: "safe", diet:{h:"y",k:"y",v:"y",vn:"y"}, al:[] },
    { c: "E297", n: "Fumaric Acid", cat: "Acidity Regulator", a: "none", p: "safe", diet:{h:"y",k:"y",v:"y",vn:"y"}, al:[] },
    { c: "E300", n: "Ascorbic Acid", cat: "Antioxidant / Vitamin", a: "none", p: "safe", diet:{h:"y",k:"y",v:"y",vn:"y"}, al:[] },
    { c: "E301", n: "Sodium Ascorbate", cat: "Antioxidant / Vitamin", a: "none", p: "safe", diet:{h:"y",k:"y",v:"y",vn:"y"}, al:[] },
    { c: "E306", n: "Tocopherols", cat: "Antioxidant / Vitamin", a: "none", p: "safe", diet:{h:"y",k:"y",v:"y",vn:"y"}, al:[] },
    { c: "E307", n: "Alpha-Tocopherol", cat: "Antioxidant / Vitamin", a: "none", p: "safe", diet:{h:"y",k:"y",v:"y",vn:"y"}, al:[] },
    { c: "E310", n: "Propyl Gallate", cat: "Antioxidant", a: "none", p: "caution", diet:{h:"y",k:"y",v:"y",vn:"y"}, al:[] },
    { c: "E316", n: "Sodium Erythorbate", cat: "Antioxidant", a: "none", p: "safe", diet:{h:"y",k:"y",v:"y",vn:"y"}, al:[] },
    { c: "E319", n: "TBHQ", cat: "Antioxidant", a: "none", p: "caution", diet:{h:"y",k:"y",v:"y",vn:"y"}, al:[] },
    { c: "E320", n: "BHA", cat: "Antioxidant", a: "low", p: "caution", diet:{h:"y",k:"y",v:"y",vn:"y"}, al:[] },
    { c: "E321", n: "BHT", cat: "Antioxidant", a: "low", p: "caution", diet:{h:"y",k:"y",v:"y",vn:"y"}, al:[] },
    { c: "E322", n: "Lecithin", cat: "Emulsifier", a: "none", p: "safe", diet:{h:"y",k:"y",v:"y",vn:"dp"}, al:["so"] },
    { c: "E330", n: "Citric Acid", cat: "Acidity Regulator", a: "none", p: "safe", diet:{h:"y",k:"y",v:"y",vn:"y"}, al:[] },
    { c: "E331", n: "Sodium Citrate", cat: "Acidity Regulator / Emulsifier", a: "none", p: "safe", diet:{h:"y",k:"y",v:"y",vn:"y"}, al:[] },
    { c: "E334", n: "Tartaric Acid", cat: "Acidity Regulator", a: "none", p: "safe", diet:{h:"d",k:"y",v:"y",vn:"y"}, al:[] },
    { c: "E338", n: "Phosphoric Acid", cat: "Acidity Regulator", a: "none", p: "generally-safe", diet:{h:"y",k:"y",v:"y",vn:"y"}, al:[] },
    { c: "E339", n: "Sodium Phosphates", cat: "Acidity Regulator / Emulsifier", a: "none", p: "generally-safe", diet:{h:"y",k:"y",v:"y",vn:"y"}, al:[] },
    { c: "E341", n: "Calcium Phosphates", cat: "Acidity Regulator / Anti-caking Agent", a: "none", p: "safe", diet:{h:"y",k:"y",v:"y",vn:"y"}, al:[] },
    { c: "E406", n: "Agar", cat: "Gelling Agent / Thickener", a: "none", p: "safe", diet:{h:"y",k:"y",v:"y",vn:"y"}, al:[] },
    { c: "E407", n: "Carrageenan", cat: "Thickener / Stabiliser", a: "none", p: "caution", diet:{h:"y",k:"y",v:"y",vn:"y"}, al:[] },
    { c: "E410", n: "Locust Bean Gum", cat: "Thickener / Stabiliser", a: "none", p: "safe", diet:{h:"y",k:"y",v:"y",vn:"y"}, al:[] },
    { c: "E412", n: "Guar Gum", cat: "Thickener / Stabiliser", a: "none", p: "safe", diet:{h:"y",k:"y",v:"y",vn:"y"}, al:[] },
    { c: "E414", n: "Gum Arabic", cat: "Emulsifier / Stabiliser", a: "none", p: "safe", diet:{h:"y",k:"y",v:"y",vn:"y"}, al:[] },
    { c: "E415", n: "Xanthan Gum", cat: "Thickener / Stabiliser", a: "none", p: "safe", diet:{h:"y",k:"y",v:"y",vn:"y"}, al:[] },
    { c: "E420", n: "Sorbitol", cat: "Sweetener / Humectant", a: "none", p: "generally-safe", diet:{h:"y",k:"y",v:"y",vn:"y"}, al:[] },
    { c: "E421", n: "Mannitol", cat: "Sweetener / Anti-caking Agent", a: "none", p: "generally-safe", diet:{h:"y",k:"y",v:"y",vn:"y"}, al:[] },
    { c: "E433", n: "Polysorbate 80", cat: "Emulsifier", a: "none", p: "caution", diet:{h:"dp",k:"dp",v:"dp",vn:"dp"}, al:[] },
    { c: "E440", n: "Pectin", cat: "Gelling Agent", a: "none", p: "safe", diet:{h:"y",k:"y",v:"y",vn:"y"}, al:[] },
    { c: "E450", n: "Diphosphates", cat: "Emulsifier / Raising Agent", a: "none", p: "generally-safe", diet:{h:"y",k:"y",v:"y",vn:"y"}, al:[] },
    { c: "E460", n: "Cellulose", cat: "Anti-caking Agent / Fibre", a: "none", p: "safe", diet:{h:"y",k:"y",v:"y",vn:"y"}, al:[] },
    { c: "E466", n: "Carboxymethyl Cellulose", cat: "Thickener / Stabiliser", a: "none", p: "generally-safe", diet:{h:"y",k:"y",v:"y",vn:"y"}, al:[] },
    { c: "E471", n: "Mono- and Diglycerides", cat: "Emulsifier", a: "none", p: "safe", diet:{h:"dp",k:"dp",v:"dp",vn:"dp"}, al:[] },
    { c: "E472e", n: "DATEM", cat: "Emulsifier / Dough Conditioner", a: "none", p: "safe", diet:{h:"dp",k:"dp",v:"dp",vn:"dp"}, al:[] },
    { c: "E476", n: "PGPR", cat: "Emulsifier", a: "none", p: "safe", diet:{h:"y",k:"y",v:"y",vn:"y"}, al:[] },
    { c: "E481", n: "Sodium Stearoyl Lactylate", cat: "Emulsifier / Dough Conditioner", a: "none", p: "safe", diet:{h:"dp",k:"dp",v:"dp",vn:"dp"}, al:[] },
    { c: "E500", n: "Sodium Bicarbonate", cat: "Raising Agent / Acidity Regulator", a: "none", p: "safe", diet:{h:"y",k:"y",v:"y",vn:"y"}, al:[] },
    { c: "E508", n: "Potassium Chloride", cat: "Flavour Enhancer / Salt Substitute", a: "none", p: "safe", diet:{h:"y",k:"y",v:"y",vn:"y"}, al:[] },
    { c: "E509", n: "Calcium Chloride", cat: "Firming Agent / Sequestrant", a: "none", p: "safe", diet:{h:"y",k:"y",v:"y",vn:"y"}, al:[] },
    { c: "E516", n: "Calcium Sulphate", cat: "Firming Agent / Flour Treatment Agent", a: "none", p: "safe", diet:{h:"y",k:"y",v:"y",vn:"y"}, al:[] },
    { c: "E536", n: "Potassium Ferrocyanide", cat: "Anti-caking Agent", a: "none", p: "safe", diet:{h:"y",k:"y",v:"y",vn:"y"}, al:[] },
    { c: "E551", n: "Silicon Dioxide", cat: "Anti-caking Agent", a: "none", p: "safe", diet:{h:"y",k:"y",v:"y",vn:"y"}, al:[] },
    { c: "E553b", n: "Talc", cat: "Anti-caking Agent / Glazing Agent", a: "none", p: "generally-safe", diet:{h:"y",k:"y",v:"y",vn:"y"}, al:[] },
    { c: "E575", n: "Glucono Delta-Lactone", cat: "Acidity Regulator / Sequestrant", a: "none", p: "safe", diet:{h:"y",k:"y",v:"y",vn:"y"}, al:[] },
    { c: "E621", n: "Monosodium Glutamate", cat: "Flavour Enhancer", a: "low", p: "generally-safe", diet:{h:"y",k:"y",v:"y",vn:"y"}, al:["hi"] },
    { c: "E901", n: "Beeswax", cat: "Glazing Agent", a: "none", p: "safe", diet:{h:"y",k:"y",v:"y",vn:"n"}, al:[] },
    { c: "E903", n: "Carnauba Wax", cat: "Glazing Agent", a: "none", p: "safe", diet:{h:"y",k:"y",v:"y",vn:"y"}, al:[] },
    { c: "E904", n: "Shellac", cat: "Glazing Agent", a: "none", p: "safe", diet:{h:"d",k:"d",v:"n",vn:"n"}, al:[] },
    { c: "E920", n: "L-Cysteine", cat: "Flour Treatment Agent", a: "none", p: "safe", diet:{h:"dp",k:"dp",v:"dp",vn:"dp"}, al:[] },
    { c: "E950", n: "Acesulfame K", cat: "Artificial Sweetener", a: "low", p: "caution", diet:{h:"y",k:"y",v:"y",vn:"y"}, al:[] },
    { c: "E951", n: "Aspartame", cat: "Artificial Sweetener", a: "low", p: "caution", diet:{h:"y",k:"y",v:"y",vn:"y"}, al:[] },
    { c: "E953", n: "Isomalt", cat: "Sweetener / Bulking Agent", a: "none", p: "generally-safe", diet:{h:"y",k:"y",v:"y",vn:"y"}, al:[] },
    { c: "E954", n: "Saccharin", cat: "Artificial Sweetener", a: "none", p: "caution", diet:{h:"y",k:"y",v:"y",vn:"y"}, al:[] },
    { c: "E955", n: "Sucralose", cat: "Artificial Sweetener", a: "low", p: "caution", diet:{h:"y",k:"y",v:"y",vn:"y"}, al:[] },
    { c: "E960", n: "Steviol Glycosides", cat: "Natural Sweetener", a: "none", p: "safe", diet:{h:"y",k:"y",v:"y",vn:"y"}, al:[] },
    { c: "E961", n: "Neotame", cat: "Artificial Sweetener", a: "none", p: "caution", diet:{h:"y",k:"y",v:"y",vn:"y"}, al:[] },
    { c: "E962", n: "Aspartame-Acesulfame Salt", cat: "Artificial Sweetener", a: "low", p: "caution", diet:{h:"y",k:"y",v:"y",vn:"y"}, al:[] },
    { c: "E965", n: "Maltitol", cat: "Sweetener / Bulking Agent", a: "none", p: "generally-safe", diet:{h:"y",k:"y",v:"y",vn:"y"}, al:[] },
    { c: "E966", n: "Lactitol", cat: "Sweetener / Bulking Agent", a: "none", p: "generally-safe", diet:{h:"y",k:"y",v:"y",vn:"n"}, al:["da"] },
    { c: "E967", n: "Xylitol", cat: "Sweetener", a: "none", p: "safe", diet:{h:"y",k:"y",v:"y",vn:"y"}, al:[] },
    { c: "E968", n: "Erythritol", cat: "Sweetener / Humectant", a: "none", p: "generally-safe", diet:{h:"y",k:"y",v:"y",vn:"y"}, al:[] },
    { c: "E1442", n: "Hydroxypropyl Distarch Phosphate", cat: "Modified Starch / Thickener", a: "none", p: "safe", diet:{h:"y",k:"y",v:"y",vn:"y"}, al:[] },
    { c: "E1520", n: "Propylene Glycol", cat: "Humectant / Solvent", a: "none", p: "caution", diet:{h:"y",k:"y",v:"y",vn:"y"}, al:[] }
  ];

  /* ── Build lookup map ── */
  var MAP = {};
  for (var i = 0; i < D.length; i++) {
    MAP[D[i].c.toUpperCase()] = D[i];
  }

  /* ── Helpers ── */
  var LINK = "https://foodlabelreader.com/tool-additive-search.html";

  function adhdLabel(v) {
    return { high: "Avoid", moderate: "Caution", low: "Low Risk", none: "Safe" }[v] || v;
  }
  function pregLabel(v) {
    return { avoid: "Avoid", caution: "Caution", "generally-safe": "Safe", safe: "Safe" }[v] || v;
  }

  function adhdColor(v) {
    return { high: "#DC2626", moderate: "#F59E0B", low: "#EAB308", none: "#16A34A" }[v] || "#16A34A";
  }
  function adhdText(v) {
    return (v === "high" || v === "none") ? "#fff" : "#1a1a1a";
  }
  function pregColor(v) {
    return { avoid: "#DC2626", caution: "#F59E0B", "generally-safe": "#16A34A", safe: "#16A34A" }[v] || "#16A34A";
  }
  function pregText(v) {
    return (v === "avoid" || v === "generally-safe" || v === "safe") ? "#fff" : "#1a1a1a";
  }

  function dietSym(v) {
    if (v === "y") return '<span class="flr-badge-diet-y">&#10003;</span>';
    if (v === "n") return '<span class="flr-badge-diet-n">&#10007;</span>';
    return '<span class="flr-badge-diet-d">?</span>';
  }
  function dietLine(add) {
    var d = add.diet || {h:"y",k:"y",v:"y",vn:"y"};
    return dietSym(d.h) + ' Halal &middot; ' + dietSym(d.k) + ' Kosher &middot; ' + dietSym(d.v) + ' Veg &middot; ' + dietSym(d.vn) + ' Vegan';
  }

  var ALLERGY_NAMES = {su:"Sulphites",az:"Azo/Aspirin",be:"Benzoates",so:"Soy",da:"Dairy",hi:"Histamine"};
  function allergyLine(add) {
    if (!add.al || !add.al.length) return '';
    return '&#9888; ' + add.al.map(function(a){return ALLERGY_NAMES[a]||a;}).join(', ');
  }

  function emoji(level) {
    if (level === "high" || level === "avoid") return "🔴";
    if (level === "moderate" || level === "caution") return "🟠";
    return "🟢";
  }

  /* ── Inject styles ── */
  var STYLE_ID = "flr-badge-styles";
  function injectStyles() {
    if (document.getElementById(STYLE_ID)) return;
    var s = document.createElement("style");
    s.id = STYLE_ID;
    s.textContent = [
      /* Reset scope */
      ".flr-badge-card,.flr-badge-compact{all:initial;display:block;box-sizing:border-box;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,'Helvetica Neue',Arial,sans-serif;line-height:1.4;-webkit-font-smoothing:antialiased;-moz-osx-font-smoothing:grayscale;}",
      ".flr-badge-card *,.flr-badge-compact *{box-sizing:border-box;margin:0;padding:0;}",

      /* ── Card mode ── */
      ".flr-badge-card{width:210px;border:1px solid #e2e2e2;border-radius:10px;background:#fff;box-shadow:0 2px 8px rgba(0,0,0,.07);overflow:hidden;color:#1a1a1a;position:relative;}",
      ".flr-badge-card .flr-badge-header{padding:14px 14px 10px;border-bottom:1px solid #f0f0f0;}",
      ".flr-badge-card .flr-badge-ecode{display:inline-block;font-size:11px;font-weight:700;letter-spacing:.5px;color:#fff;background:#1B4332;border-radius:4px;padding:2px 7px;margin-bottom:6px;}",
      ".flr-badge-card .flr-badge-name{display:block;font-size:14px;font-weight:600;color:#1a1a1a;margin-bottom:2px;}",
      ".flr-badge-card .flr-badge-cat{display:block;font-size:11px;color:#777;margin-bottom:8px;}",
      ".flr-badge-card .flr-badge-pills{display:flex;gap:6px;flex-wrap:wrap;}",
      ".flr-badge-card .flr-badge-pill{display:inline-flex;align-items:center;font-size:10.5px;font-weight:600;border-radius:20px;padding:3px 9px;letter-spacing:.2px;white-space:nowrap;}",
      ".flr-badge-card .flr-badge-pill-label{opacity:.85;margin-right:3px;font-weight:500;}",
      ".flr-badge-card .flr-badge-footer{padding:8px 14px;display:flex;align-items:center;justify-content:space-between;}",
      ".flr-badge-card .flr-badge-powered{font-size:9px;color:#aaa;text-decoration:none;}",
      ".flr-badge-card .flr-badge-powered:hover{color:#1B4332;}",
      ".flr-badge-card .flr-badge-learn{font-size:11px;font-weight:600;color:#D4956A;text-decoration:none;white-space:nowrap;}",
      ".flr-badge-card .flr-badge-learn:hover{color:#1B4332;text-decoration:underline;}",

      /* Card dark theme */
      ".flr-badge-card.flr-badge-dark{background:#1a1a1a;border-color:#333;box-shadow:0 2px 8px rgba(0,0,0,.3);}",
      ".flr-badge-card.flr-badge-dark .flr-badge-header{border-bottom-color:#2a2a2a;}",
      ".flr-badge-card.flr-badge-dark .flr-badge-name{color:#f0f0f0;}",
      ".flr-badge-card.flr-badge-dark .flr-badge-cat{color:#999;}",
      ".flr-badge-card.flr-badge-dark .flr-badge-powered{color:#666;}",
      ".flr-badge-card.flr-badge-dark .flr-badge-powered:hover{color:#D4956A;}",

      /* ── Compact mode ── */
      ".flr-badge-compact{display:inline-flex;align-items:center;gap:6px;height:36px;padding:0 14px;border-radius:20px;background:#f5f5f5;border:1px solid #e0e0e0;font-size:12px;font-weight:500;color:#333;text-decoration:none;cursor:pointer;white-space:nowrap;transition:box-shadow .15s ease,border-color .15s ease;}",
      ".flr-badge-compact:hover{border-color:#D4956A;box-shadow:0 1px 4px rgba(0,0,0,.08);}",
      ".flr-badge-compact .flr-badge-c-code{font-weight:700;color:#1B4332;}",
      ".flr-badge-compact .flr-badge-c-sep{color:#ccc;margin:0 1px;}",
      ".flr-badge-compact .flr-badge-c-label{font-size:11px;color:#666;}",

      /* Compact dark theme */
      ".flr-badge-compact.flr-badge-dark{background:#2a2a2a;border-color:#444;color:#ddd;}",
      ".flr-badge-compact.flr-badge-dark .flr-badge-c-code{color:#7fcca5;}",
      ".flr-badge-compact.flr-badge-dark .flr-badge-c-sep{color:#555;}",
      ".flr-badge-compact.flr-badge-dark .flr-badge-c-label{color:#aaa;}",
      ".flr-badge-compact.flr-badge-dark:hover{border-color:#D4956A;}",

      /* ── Dietary info ── */
      ".flr-badge-card .flr-badge-diet{padding:6px 14px 2px;font-size:10px;color:#777;line-height:1.6;letter-spacing:.2px}",
      ".flr-badge-card.flr-badge-dark .flr-badge-diet{color:#999}",
      ".flr-badge-diet-y{color:#16A34A;font-weight:700}",
      ".flr-badge-diet-n{color:#DC2626;font-weight:700}",
      ".flr-badge-diet-d{color:#F59E0B;font-weight:700}",

      /* ── Allergy info ── */
      ".flr-badge-card .flr-badge-allergy{padding:4px 14px 2px;font-size:10px;font-weight:600;color:#B91C1C;line-height:1.6;letter-spacing:.2px}",
      ".flr-badge-card.flr-badge-dark .flr-badge-allergy{color:#FCA5A5}",

      /* ── Unknown state ── */
      ".flr-badge-unknown{all:initial;display:inline-flex;align-items:center;box-sizing:border-box;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,'Helvetica Neue',Arial,sans-serif;font-size:12px;color:#999;background:#fafafa;border:1px solid #e8e8e8;border-radius:8px;padding:8px 12px;gap:6px;}",
      ".flr-badge-unknown.flr-badge-dark{background:#222;border-color:#444;color:#777;}",
      ".flr-badge-unknown a{color:#D4956A;font-size:11px;text-decoration:none;font-weight:500;}",
      ".flr-badge-unknown a:hover{text-decoration:underline;}"
    ].join("\n");
    document.head.appendChild(s);
  }

  /* ── Build card HTML ── */
  function buildCard(add, dark) {
    var el = document.createElement("div");
    el.className = "flr-badge-card" + (dark ? " flr-badge-dark" : "");
    el.innerHTML =
      '<div class="flr-badge-header">' +
        '<span class="flr-badge-ecode">' + add.c + '</span>' +
        '<span class="flr-badge-name">' + add.n + '</span>' +
        '<span class="flr-badge-cat">' + add.cat + '</span>' +
        '<div class="flr-badge-pills">' +
          '<span class="flr-badge-pill" style="background:' + adhdColor(add.a) + ";color:" + adhdText(add.a) + '">' +
            '<span class="flr-badge-pill-label">ADHD:</span> ' + adhdLabel(add.a) +
          '</span>' +
          '<span class="flr-badge-pill" style="background:' + pregColor(add.p) + ";color:" + pregText(add.p) + '">' +
            '<span class="flr-badge-pill-label">Pregnancy:</span> ' + pregLabel(add.p) +
          '</span>' +
        '</div>' +
        '<div class="flr-badge-diet">' + dietLine(add) + '</div>' +
        (add.al && add.al.length ? '<div class="flr-badge-allergy">' + allergyLine(add) + '</div>' : '') +
      '</div>' +
      '<div class="flr-badge-footer">' +
        '<a class="flr-badge-powered" href="' + LINK + '" target="_blank" rel="noopener">Powered by FoodLabelReader</a>' +
        '<a class="flr-badge-learn" href="' + LINK + '" target="_blank" rel="noopener">Learn more →</a>' +
      '</div>';
    return el;
  }

  /* ── Build compact HTML ── */
  function buildCompact(add, dark) {
    var el = document.createElement("a");
    el.className = "flr-badge-compact" + (dark ? " flr-badge-dark" : "");
    el.href = LINK;
    el.target = "_blank";
    el.rel = "noopener";
    el.title = add.n + " — ADHD: " + adhdLabel(add.a) + ", Pregnancy: " + pregLabel(add.p) + " (FoodLabelReader)";
    el.innerHTML =
      '<span class="flr-badge-c-code">' + add.c + '</span>' +
      '<span class="flr-badge-c-sep">·</span>' +
      '<span class="flr-badge-c-label">ADHD: ' + emoji(add.a) + '</span>' +
      '<span class="flr-badge-c-sep">·</span>' +
      '<span class="flr-badge-c-label">Preg: ' + emoji(add.p) + '</span>';
    return el;
  }

  /* ── Build unknown state ── */
  function buildUnknown(code, dark) {
    var el = document.createElement("div");
    el.className = "flr-badge-unknown" + (dark ? " flr-badge-dark" : "");
    el.innerHTML =
      '<span>' + (code ? code + ' — ' : '') + 'Unknown additive</span>' +
      '<a href="' + LINK + '" target="_blank" rel="noopener">Search →</a>';
    return el;
  }

  /* ── Render all badges ── */
  function renderAll() {
    injectStyles();
    var els = document.querySelectorAll(".flr-safety-badge");
    for (var i = 0; i < els.length; i++) {
      var el = els[i];
      /* Skip already rendered */
      if (el.getAttribute("data-flr-rendered")) continue;
      el.setAttribute("data-flr-rendered", "1");

      var code = (el.getAttribute("data-additive") || "").toUpperCase().trim();
      var style = (el.getAttribute("data-style") || "card").toLowerCase();
      var dark = (el.getAttribute("data-theme") || "").toLowerCase() === "dark";
      var add = MAP[code];
      var child;

      if (!add) {
        child = buildUnknown(code, dark);
      } else if (style === "compact") {
        child = buildCompact(add, dark);
      } else {
        child = buildCard(add, dark);
      }

      el.appendChild(child);
    }
  }

  /* ── Init ── */
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", renderAll);
  } else {
    renderAll();
  }

  /* Expose re-render for SPAs that add badges dynamically */
  window.FLRSafetyBadge = { render: renderAll };
})();
