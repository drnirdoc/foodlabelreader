const CACHE_NAME = 'flr-v22.34';
const PRECACHE_URLS = [
  '/glossary',
  '/privacy',
  '/renal',
  '/vegan',
  '/whats-new',
  '/fodmap',
  '/',
  '/us-food-dye-ban',
  '/tool-ingredient-scanner',
  '/tool-additive-search',
  '/tool-allergen-decoder',
  '/tool-phosphate-detector',
  '/tool-fodmap-scanner',
  '/tool-dye-ban-tracker',
  '/tool-emulsifier-detector',
  '/tool-diabetes-food-checker',
  '/tool-brand-compare',
  '/quiz-pregnancy',
  '/quiz-postpartum',
  '/adhd',
  '/halal',
  '/hindu',
  '/diabetes',
  '/pregnancy',
  '/vegetarian',
  '/gluten-free',
  '/jain',
  '/halal-ar',
  '/jain-hi',
  '/guides',
  '/resources',
  '/disclaimer',
  '/sources',
  '/about',
  '/blog/',
  '/blog/adhd-food-dyes-guide',
  '/blog/adhd-food-dyes-complete-list',
  '/blog/e-numbers-ranked',
  '/blog/e-numbers-banned-by-country',
  '/blog/e-numbers-safe-for-babies-toddlers',
  '/blog/e102-tartrazine',
  '/blog/e110-sunset-yellow',
  '/blog/e129-allura-red',
  '/blog/e150d-caramel-colour',
  '/blog/e160b-annatto',
  '/blog/e200-sorbic-acid',
  '/blog/e210-benzoic-acid',
  '/blog/e211-sodium-benzoate',
  '/blog/e220-sulphur-dioxide',
  '/blog/e223-sodium-metabisulphite',
  '/blog/e250-sodium-nitrite',
  '/blog/e282-calcium-propionate',
  '/blog/e300-ascorbic-acid',
  '/blog/e321-bht',
  '/blog/e330-citric-acid',
  '/blog/e420-sorbitol',
  '/blog/e425-konjac',
  '/blog/e471-emulsifier',
  '/blog/e516-calcium-sulphate',
  '/blog/e621-msg',
  '/blog/e621-msg-pregnancy',
  '/blog/e627-disodium-guanylate',
  '/blog/e904-shellac',
  '/blog/e951-aspartame',
  '/blog/e952-cyclamate',
  '/blog/feingold-diet-guide',
  '/blog/fodmap-emulsifiers-ibs-guide',
  '/blog/food-additive-numbers-australia',
  '/blog/hidden-animal-ingredients-food',
  '/blog/hidden-sugars-baby-food',
  '/blog/hidden-sugars-diabetes-guide',
  '/blog/is-it-halal-food-additives',
  '/blog/pregnancy-safe-e-numbers',
  '/blog/red-dye-40-adhd',
  '/blog/sweeteners-950-951',
  '/blog/dairy-additives-acne-guide',
  '/blog/dairy-products-halal-guide',
  '/blog/high-gi-additives-acne',
  '/acne',
  '/widgets/',
  '/kosher',
  '/kosher-symbols',
  '/ask',
  '/data/kb.json',
  '/histamine',
  '/medication-interactions',
  '/tool-allergen-card',
  '/oxalate',
  '/sulphites',
  '/ultra-processed',
  '/lactose-vs-dairy',
  '/nightshade',
  '/salicylates',
  '/sports-nutrition',
  '/aip',
  '/manifest.json'
];

// Install — precache core pages
self.addEventListener('install', e => {
  e.waitUntil(
    caches.open(CACHE_NAME)
      .then(cache => cache.addAll(PRECACHE_URLS))
      .then(() => self.skipWaiting())
  );
});

// Activate — clean old caches
self.addEventListener('activate', e => {
  e.waitUntil(
    caches.keys().then(keys =>
      Promise.all(keys.filter(k => k !== CACHE_NAME).map(k => caches.delete(k)))
    ).then(() => self.clients.claim())
  );
});

// Fetch — cache-first for same-origin, network-first for CDN
self.addEventListener('fetch', e => {
  const url = new URL(e.request.url);

  // Network-first for CDN resources (Tesseract, etc.)
  if (url.origin !== location.origin) {
    e.respondWith(
      fetch(e.request)
        .then(res => {
          if (res.ok) {
            const clone = res.clone();
            caches.open(CACHE_NAME).then(cache => cache.put(e.request, clone));
          }
          return res;
        })
        .catch(() => caches.match(e.request))
    );
    return;
  }

  // Network-first for page navigations (HTML). This is the fix for
  // "I always open a cached version": a cache-first strategy here meant
  // a visitor's very next visit after a deploy could still be served the
  // previous build's HTML, even after CACHE_NAME had been bumped, because
  // the in-flight navigation is served before the new worker takes
  // control. Navigations now always try the network first and only fall
  // back to the cache (offline support) if that fails.
  if (e.request.mode === 'navigate') {
    e.respondWith(
      fetch(e.request)
        .then(res => {
          if (res.ok) {
            const clone = res.clone();
            caches.open(CACHE_NAME).then(cache => cache.put(e.request, clone));
          }
          return res;
        })
        .catch(() => caches.match(e.request).then(cached => cached || caches.match('/')))
    );
    return;
  }

  // Cache-first for same-origin
  e.respondWith(
    caches.match(e.request)
      .then(cached => cached || fetch(e.request).then(res => {
        if (res.ok) {
          const clone = res.clone();
          caches.open(CACHE_NAME).then(cache => cache.put(e.request, clone));
        }
        return res;
      }))
  );
});
